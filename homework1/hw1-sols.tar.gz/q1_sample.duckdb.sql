-- List all medal types in alphabetical order.

select distinct(name) from medal_info order by name;